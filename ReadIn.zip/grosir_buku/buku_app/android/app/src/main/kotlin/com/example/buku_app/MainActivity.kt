package com.example.buku_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
